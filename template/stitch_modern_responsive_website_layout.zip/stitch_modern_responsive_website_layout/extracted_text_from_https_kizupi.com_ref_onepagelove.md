Skip to content

[](/) Parents Teachers Schools [Help](/help)

[Sign in](/app/signin) [**Start learning** →](/app) [**Try Kizupi FREE** for 7 days!](/app)

Parents Teachers Schools [Help](/help) [Contact](/contact) [Sign in](/app/signin) [Start learning](/app)

# The math tutor that asks why.

Kizupi is a pixel owl who helps kids think it through: it listens, asks “how do you know?”, and never rushes to the answer.

[Try Kizupi FREE for 7 days __](/app) Try a problem

Then just $5/mo. billed yearly, or $10/mo. Cancel anytime.

  * **Grades 1–6** Every lesson, every grade
  * **Gentle hints** Only as much help as they need
  * **Worlds to explore** Each with its own buddy
  * **English and Spanish** Read, captioned and spoken



## It doesn’t give the answer. It asks.

Then it hints, one small step at a time, and only as much as your child needs. Try it: pick an answer, or ask for a hint.

  1.   2.   3.   4.   5.   6.   7. 


No hints yet · Kizupi waits

**Grade 1 sample** · Take-away

Anna gave away 3 apples. She has 5 left. How many did she start with?

Take your time. I’m right here.

Pick an answer

2 5 8

I’m stuck New question

  * ### A math engine checks every step

Exact arithmetic, never guessed by a chatbot.

  * ### Teaching rules decide every move

A fixed plan picks when to wait, hint or ask “how did you get that?”

  * ### Said kindly, out loud

Every problem is read aloud; answer by voice or by tapping.




## You’re in charge. Without hovering.

See what they learned and where it was hard, change how long lessons run, and keep it all private.

[Set up your family __](/app)

  * ### A weekly note

What they learned, in their own words, in your inbox on Monday morning.

  * ### A Progress page

This week at a glance, skills by group, and ideas to try at home.

  * ### Settings behind a PIN

Lesson length, tracks and language stay yours to change.

  * ### Private by default

A nickname, not a name. No ads, no trackers. [Privacy](/privacy)




## Practice at home that sounds like your classroom.

Kizupi asks “how do you know?”, waits before it hints, and never hands over the answer. It gives children a place to practice reasoning between lessons.

[Try it yourself __](/app)[Talk to us](/contact?role=teacher)

  * **Reasoning first**

Word problems, pictures and early algebra for Grades 1–6, one idea built on the last.

  * **Hints, not answers**

Seven small steps, from a pause to a walk-through, and only as far as the child needs.

  * **Room for every learner**

Read aloud with captions, a dyslexia-friendly font, and help in Spanish.

  * **Families stay in the loop**

A weekly note and a Progress page show parents what was practiced and where it was hard.




## Ready for your families. Private by design.

Kizupi runs in the browser on the tablets families already have, and keeps children’s data to the least a tutor can work with.

[Talk to us __](/contact?role=school)[Read the privacy policy](/privacy)

  * ### No child accounts

Children never sign in or type an email. A parent sets up the tablet.

  * ### No ads, no trackers

Children never see prices or anything to buy, and their data is never sold or used for marketing.

  * ### Parents in control

Families can see, export and delete everything, at any time.

  * ### Nothing to install

Works in the browser, or add it to the home screen. No app store needed.




## The things parents ask first.

Every family starts with a 7-day free trial. Something else? [Write to us](/contact), a person answers.

01How much does it cost?

Kizupi Family is $10 a month, or $60 a year ($5 a month), for up to 4 children, and every family starts with a 7-day free trial. A card is needed to start the trial, nothing is charged for 7 days, and you can cancel anytime. No ads, and we never sell your child’s data.

02What do I need?

A tablet (or a phone or computer) and an internet connection. Lessons are made to be held sideways. Use it in the browser or add it to the home screen.

03Is it a chatbot?

No. A math engine checks every answer, a fixed set of teaching rules decides what happens next, and Kizupi only says lines that were prepared and checked before your child ever hears them. It can’t be steered into open chat.

04How does it teach?

Reasoning before procedure, early algebra, and a steady “why?” until the idea is theirs.

05How long is a lesson?

About 20 minutes in Grades 1 and 2, 25 in Grades 3 and 4, and 35 in Grades 5 and 6. You can pick anything from 15 to 45.

06Can two parents follow along?

Yes. Invite a co-parent from Settings → Grown-ups. They sign in with their own email and see the same children and progress.

07What does “Kizupi” mean?

Say “kee-zoo-pee.” It comes from _kizuki_ , Japanese for noticing something new.

08Does Kizupi speak other languages?

Yes. English always works, and you can turn on help in Spanish. Kizupi then reads, captions and helps in Spanish, and your child can answer in it. Numbers and math stay exactly as written.

## Say hello to Kizupi.

Set up your family in a minute. Kizupi takes it from there.

[Try Kizupi FREE for 7 days __](/app)[Contact us](/contact)

Then just $5/mo. billed yearly, or $10/mo. Cancel anytime.

  * 7-day free trial
  * Grades 1–6
  * No ads, no trackers



[](/)

© Kizupi · Made for curious kids.

  * [About](/about)
  * [Chrome extension](/chrome)
  * [Help](/help)
  * [Privacy](/privacy)
  * [Terms](/terms)
  * [Changelog](/changelog)
  * [Contact](/contact)