---
name: Nocturne Pixel Scaffolding
colors:
  surface: '#0c1511'
  surface-dim: '#0c1511'
  surface-bright: '#323b36'
  surface-container-lowest: '#07100c'
  surface-container-low: '#141d19'
  surface-container: '#18221d'
  surface-container-high: '#232c27'
  surface-container-highest: '#2d3732'
  on-surface: '#dbe5de'
  on-surface-variant: '#c3c9b1'
  inverse-surface: '#dbe5de'
  inverse-on-surface: '#29322e'
  outline: '#8d937d'
  outline-variant: '#434937'
  surface-tint: '#a0d73f'
  primary: '#fbffe9'
  on-primary: '#233600'
  primary-container: '#b9f257'
  on-primary-container: '#4a6d00'
  inverse-primary: '#476800'
  secondary: '#7ed9a1'
  on-secondary: '#00391f'
  secondary-container: '#037244'
  on-secondary-container: '#97f4b9'
  tertiary: '#fffcff'
  on-tertiary: '#4e2600'
  tertiary-container: '#ffd9bf'
  on-tertiary-container: '#935318'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#bbf459'
  primary-fixed-dim: '#a0d73f'
  on-primary-fixed: '#121f00'
  on-primary-fixed-variant: '#344e00'
  secondary-fixed: '#99f6bc'
  secondary-fixed-dim: '#7ed9a1'
  on-secondary-fixed: '#002110'
  on-secondary-fixed-variant: '#00522f'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#ffb780'
  on-tertiary-fixed: '#2f1400'
  on-tertiary-fixed-variant: '#6f3800'
  background: '#0c1511'
  on-background: '#dbe5de'
  surface-variant: '#2d3732'
  canvas-midnight: '#13192B'
  surface-nocturne: '#161D31'
  surface-cream: '#F6F4EC'
  brand-forest: '#0B4E32'
  brand-mint: '#65E067'
  brand-lime: '#72EB76'
  text-on-dark: '#FFFFFF'
  text-dark: '#0E1713'
  border-dark: '#161D31'
  border-subtle: '#E5E1D3'
typography:
  display:
    fontFamily: Bricolage Grotesque
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Bricolage Grotesque
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
  body-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 19px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  code-num:
    fontFamily: Bricolage Grotesque
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 22px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The brand personality is patient, empathetic, playful, and intellectually reassuring. It bridges the joyful nostalgia of 8-bit retro gaming with modern, highly structured pedagogical software. Designed for elementary learners (grades 1–6), parents, and educators, the interface rejects hyperactive gamification, anxiety-inducing timers, and unpredictable AI chat loops. Instead, it projects gentle curiosity, structured safety, and deterministic mathematical pacing.

Visually, the style merges **Modern Editorial Neo-Brutalism** with **Retro Pixel-Craft**. Deep midnight canvas backgrounds transition into crisp, clean warm-cream surface tiles and high-voltage chartreuse/mint accents. Crisp dark borders (1.5px to 2px solid), structured retro checkered dithering patterns, and chunky interactive pills evoke tactile handheld game consoles while maintaining the utmost readability and WCAG AAA accessibility for neurodivergent and dyslexic readers.

## Colors

The system uses an intentional dual-atmosphere palette:

- **Primary (`#B9F257`)**: An electric lime that acts as the primary focal beacon, signaling active highlights, key CTA conversions, and step progression.
- **Secondary (`#117849` / `#0B4E32`)**: Grounding forest greens providing deep, trustworthy pedagogical contrast against light backgrounds.
- **Tertiary (`#F4A261`)**: A warm marigold-amber reserved exclusively for assistive interventions, such as the "I'm stuck" state and empathetic tutor prompt nudges.
- **Canvas & Surface Stack**: Deep slate-indigo (`#13192B`, `#161D31`) drives the hero and nighttime immersion spaces, while the learning playground shifts to an ultra-readable warm cream (`#F6F4EC`) to ease screen fatigue during prolonged problem-solving.
- **Contrast Ratios**: Body text on cream surfaces stays locked to high-contrast charcoal (`#0E1713`), exceeding AA and AAA readability standards.

## Typography

Typography balances bold, quirky charisma with strict pedagogical accessibility.

- **Headlines (`Bricolage Grotesque`)**: Characterful, confident, and slightly eccentric, infusing geometric retro flair into editorial headers. Headings pair expressive weights with compact line-heights and slight negative tracking.
- **Body & Labels (`Atkinson Hyperlegible Next`)**: Selected deliberately for high-legibility distinctions across easily confused characters (e.g., `1`, `l`, `I`, `0`, `O`). This provides an inclusive reading canvas for developing minds and dyslexic students.
- **Numbers & Choice Tokens**: Rendered with generous target scale and distinct numeric shapes to ensure zero cognitive ambiguity during test questions.

## Layout & Spacing

The layout is built around a hybrid 12-column modular grid with responsive breakpoints at 640px (mobile), 1024px (tablet landscape / small desktop), and 1280px (full desktop).

- **Tablet-First Landscape Preference**: Content blocks and interactive sandboxes are proportioned to support 4:3 and 16:10 landscape orientations commonly used in classrooms and tablet covers.
- **Section Rhythm**: Sections alternate between dark slate night atmospheres and bright cream cards. Section transitions are demarcated with distinct retro pixel-checkerboard banding (dithered pixel ribbons) measuring 24px in height.
- **Horizontal & Vertical Pacing**: Component cards maintain consistent internal padding using `space-lg` (24px) on desktop and `space-md` (16px) on mobile to keep touch targets generous (minimum 48px height for all interactive elements).

## Elevation & Depth

Visual hierarchy uses physical, game-cartridge Neo-Brutalism rather than soft, diffuse blurs:

- **Solid Offset Drop-Shadows (Tactile Depth)**: Interactive elements and cards utilize hard, crisp shadows with zero blur radius: `2px 2px 0px #0E1713` for cards and unpressed buttons, transitioning to `0px 0px 0px` on `:active` tap states to replicate authentic button depression.
- **Structured Outlines**: High-contrast, clean 1.5px to 2px solid outlines define all surface cards, floating speech dialogs, and answer options, preventing visual bleeding across light or dark containers.
- **Overlay Dialogues**: Tutor speech bubbles feature an offset tail anchor and subtle inner padding with an off-white background (`#FFFDF7`) surrounded by a crisp `1.5px solid #161D31` border.

## Shapes

The shape system pairs rounded contours with rigid pixel geometry.

- **Standard Containers (`roundedness: 2`)**: Interactive cards, sandboxes, and dialog prompts feature an 8px (`0.5rem`) corner radius. Larger feature panels use 16px (`1rem`) to keep large compositions friendly.
- **Action Pills**: Multiple-choice tokens and CTA buttons feature elongated, friendly pill-like radii (up to `2rem`) or soft 12px pill geometry, ensuring child-friendly, touch-safe interfaces.
- **Pixel flourishes**: Avatar sprites, section transition checkering, and step dots adhere to an unwavering 4px virtual pixel grid.

## Components

### Buttons & Interactive CTAs
- **Primary CTA**: High-contrast filled button in `brand-lime` (`#B9F257`) with `text-dark` typography, bold weight, 2px solid dark border, and a 2px offset hard shadow. On press: translates down-right 2px with shadow collapsing to 0.
- **Secondary / Ghost Button**: White or transparent background with a crisp 1.5px border (`#161D31`), black text, and pill or 12px rounded profile.
- **Assistive Button ("I'm stuck")**: Warm amber fill (`#F4A261`), dark text, communicating safety and warmth without signaling failure or negative error states.

### Interactive Choice Selectors (Problem Options)
- Large, touch-friendly rectangular pills (min height 54px).
- White surface, 2px border `#161D31`, centered large numerical typography (`code-num`).
- Hover/focus reveals a soft lime wash (`#B9F257` at 20% opacity) or dark inset stroke.
- Selected state activates full `brand-lime` background fill with inset ink text.

### The 7-Step Hint Ladder
- A continuous horizontal sequence of 7 segment indicators (`1.` to `7.`).
- Inactive segments: 4px high bars in muted cream or soft gray (`#E5E1D3`).
- Active segment: Glowing mint/lime bar accompanied by subtle status microcopy (`"No hints yet · Kizupi waits"`).

### Speech & Avatar Dialogue
- Kizupi the pixel owl paired directly with a comic-style speech capsule.
- Background: `#FFFDF7` on light surfaces or `#202945` on nocturnal surfaces.
- Text: Italicized, supportive copy (`"Take your time. I’m right here."`).

### Feature & Trust Cards
- Pure white (`#FFFFFF`) or light cream cards resting over dark canvas.
- Crisp 1.5px border, pill badge tags at top left, bold header, and clear paragraph text.

### Retro Checkered Dividers
- Horizontal divider ribbon made of a two-row alternating 4px/8px black-and-white or green-and-white dither pattern, creating seamless nostalgic transitions between dark and light thematic sections.