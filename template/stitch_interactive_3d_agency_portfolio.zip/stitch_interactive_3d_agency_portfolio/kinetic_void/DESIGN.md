---
name: Kinetic Void
colors:
  surface: '#13140f'
  surface-dim: '#13140f'
  surface-bright: '#393a34'
  surface-container-lowest: '#0e0f0a'
  surface-container-low: '#1b1c17'
  surface-container: '#1f201b'
  surface-container-high: '#2a2a25'
  surface-container-highest: '#353530'
  on-surface: '#e4e2db'
  on-surface-variant: '#cfc6ab'
  inverse-surface: '#e4e2db'
  inverse-on-surface: '#30312c'
  outline: '#989077'
  outline-variant: '#4c4732'
  surface-tint: '#e7c400'
  primary: '#fff7e6'
  on-primary: '#3a3000'
  primary-container: '#ffd900'
  on-primary-container: '#715f00'
  inverse-primary: '#6f5d00'
  secondary: '#cbc6c1'
  on-secondary: '#32302d'
  secondary-container: '#4b4945'
  on-secondary-container: '#bdb7b3'
  tertiary: '#e1fdff'
  on-tertiary: '#00363a'
  tertiary-container: '#0af2ff'
  on-tertiary-container: '#006b71'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe165'
  primary-fixed-dim: '#e7c400'
  on-primary-fixed: '#221b00'
  on-primary-fixed-variant: '#544600'
  secondary-fixed: '#e7e1dc'
  secondary-fixed-dim: '#cbc6c1'
  on-secondary-fixed: '#1d1b18'
  on-secondary-fixed-variant: '#494643'
  tertiary-fixed: '#74f5ff'
  tertiary-fixed-dim: '#00dbe7'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f54'
  background: '#13140f'
  on-background: '#e4e2db'
  surface-variant: '#353530'
  obsidian-base: '#0B0A09'
  surface-charcoal: '#161513'
  surface-elevated: '#211F1C'
  surface-border: '#2E2B27'
  text-stark: '#F0EEE6'
  text-muted: '#8A867F'
  accent-electric: '#FFD900'
  accent-cyan-flare: '#00FFCC'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 96px
    fontWeight: '700'
    lineHeight: 96px
    letterSpacing: -0.04em
  display-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 68px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 46px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: 0em
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Space Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.06em
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.1em
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
  space-2xl: 5rem
  space-3xl: 8rem
---

## Brand & Style
This design system embodies high-impact digital craftsmanship, catering to creative directors, luxury brands, and forward-thinking tech innovators seeking cutting-edge motion and 3D experiences. Rooted in a dark, hyper-minimalist aesthetic punctuated by searing chromatic energy, the visual language merges the technical precision of creative code with high-fashion editorial restraint.

The style fuses **Brutal Minimalist Precision** with **Fluid Interactive Scenography**:
- **Monolithic Visual Weight:** Searing stark white display typography floats over near-infinite obsidian depths, framing WebGL and interactive canvas viewports without ornamental clutter.
- **Electric Accentuation:** High-voltage acid-tinged lime yellow cuts through pitch black surfaces, drawing focus solely to critical calls to action, active navigation states, and interactive scrubbing handles.
- **Technical Rigor:** Strict modular layouts paired with monospaced metadata and coordinates evoke behind-the-scenes production dashboards, conferring institutional confidence and creative authority.

## Colors
The palette is built strictly for dark-mode immersion, maximizing screen contrast to allow interactive 3D motion surfaces and reel captures to project forward.

- **Primary (`#FFD900`):** Searing acid-gold, operating as an electric signal layer. Applied sparingly to interactive highlights, hover states, timeline progress indicators, and primary conversion targets.
- **Secondary (`#211F1C`):** Deep volcanic charcoal, serving as contextual background grouping, elevated modular panels, and structural pill badges.
- **Neutral (`#F0EEE6`):** Bone alabaster, providing crisp, uncompromised legibility across editorial headings and critical metadata without the aggressive glare of pure `#FFFFFF`.
- **Named Surfaces & Accents:**
  - `obsidian-base` (`#0B0A09`): Deepest infinite canvas foundation behind canvas shaders.
  - `surface-charcoal` (`#161513`) & `surface-elevated` (`#211F1C`): Controlled layers of spatial tiering.
  - `surface-border` (`#2E2B27`): Subdued structural divider lines.
  - `accent-cyan-flare` (`#00FFCC`): Secondary kinetic flare reserved for live WebGL cursor states and real-time computational data badges.

## Typography
Typography is split into two distinct mechanical registers:

1. **Editorial Architecture (`Space Grotesk`):** Tight, geometric, high-impact display typography. Display scales use negative tracking and condensed vertical cadence to feel imposing, cinematic, and industrial. Body scales remain sharp, readable, and modernist.
2. **Technical Metadata (`JetBrains Mono`):** Monospaced labels establish the studio's technical execution capability. Used exclusively for case study categorization, timecodes, canvas framerates (e.g., `60 FPS // WEBGL`), coordinates, and indexing numbers (`01/12`). Monospaced text is rendered in uppercase with wide letter tracking.

## Layout & Spacing
The layout follows a modular 12-column grid system bounded by hairline dividers. Content structure alternates between expansive full-bleed media viewports and rigid multi-column metadata bands.

- **Desktop (1200px+):** 12-column fluid grid, 3rem margins, 1.5rem gutters. Sections are anchored by visible or implied structural axes. Project metadata sits in dedicated 3-column side rails adjacent to 9-column dynamic media panels.
- **Tablet (768px - 1199px):** 8-column layout with 2rem margins. Metadata sits above media elements in stacked horizontal spans.
- **Mobile (<768px):** 4-column layout, 1.25rem margins, 1rem gutters. Hero headlines wrap deliberately into punchy, broken-line editorial stacks. Interactive WebGL canvas viewports preserve fixed aspect ratios (4:5 or 1:1) to prevent scroll hijacking.
- **Vertical Rhythm:** Macro spacing uses dramatic rhythm jumps (`space-2xl` and `space-3xl`) to create breathless visual decompression between client showcases.

## Elevation & Depth
Depth is constructed through **tonal stratification and razor-thin borders**, completely rejecting diffused drop shadows. In a performance-first 3D/motion portfolio, heavy CSS box shadows introduce GPU rendering overhead and dilute crisp geometries.

- **Level 0 (Infinite Ground):** Canvas background `#0B0A09` hosting WebGL shaders, grain shaders, or video reel backgrounds.
- **Level 1 (Structural Tier):** Modular cards and panels rendered in `#161513` or `#211F1C` with `1px solid #2E2B27` borders. 
- **Level 2 (Active Floating / HUD):** Floating transport controls, video scrubs, and sticky navigation use dark glass translucent backdrops (`rgba(17, 16, 14, 0.8)` with `backdrop-filter: blur(16px)` and a `1px solid rgba(240, 238, 230, 0.12)` border).
- **Interactive Light Injection:** Focus and active states do not lift on the Z-axis with shadows; instead, borders instantly transition from muted slate `#2E2B27` to intense `#FFD900` or `#00FFCC`, producing an energized electric perimeter.

## Shapes
This design system uses a strictly **Sharp (`0`)** shape language.

- **Zero Curvature:** All viewports, project cards, input surfaces, and outer containers feature absolute right angles (`border-radius: 0px`). This evokes photographic contact sheets, digital cutting rooms, and cinematic production monitors.
- **Functional Exceptions:** Micro pill chips (e.g., status tags showing `LIVE EXPERIMENT` or `REEL 2025`) and video scrub scrubbers may utilize an intentional full capsule pill shape to establish distinct interactive affordance against the rigid architectural grid.

## Components

### Buttons & Interactive Triggers
- **Primary Action:** Solid `#FFD900` fill, pure black `#0B0A09` bold `Space Grotesk` typography, rectangular silhouette (`roundedness: 0`). Micro-interaction: On hover, typography shifts position slightly while a fine-line inset border snaps inward.
- **Secondary Action (Ghost / Frame):** Transparent background, `1px solid #2E2B27` border, `#F0EEE6` label. On hover, the border flashes to `#FFD900` and the label shifts to bright yellow.
- **Magnetic Link:** Inline navigation items paired with small JetBrains Mono numerical indices (`01`, `02`). Hover triggers an animated underline running from left to right in `#FFD900`.

### Chips & Metadata Tags
- Monospaced typography (`label-mono-sm`), uppercase, tracking `0.1em`.
- Contained within `1px solid #2E2B27` borders with `#161513` background. Live interactive statuses feature a pulsing `4px` dot in `#00FFCC`.

### Cards (Case Studies & Project Tiles)
- Full bleed media enclosures bounded by razor-thin borders (`1px solid #2E2B27`).
- Image / WebGL canvas is desaturated or subdued at rest, bursting into full color and fluid motion upon cursor proximity or entry.
- Floating overlay panels pin category, client, and release year to the bottom corners using monospaced metadata bands.

### Lists & Index Views
- Monolithic horizontal list layout: Alternating rows separated by `1px solid #2E2B27`.
- Hovering a row triggers a floating video thumbnail preview tracking the cursor across the screen, while the row text transitions from `#8A867F` to `#F0EEE6` with an electric yellow bullet point.

### Inputs & Contact Fields
- Underline-only or raw rectangular cells using `#161513` fill with `1px solid #2E2B27` baseline.
- Focus state: Border illuminates to `#FFD900`; label animates upward in `JetBrains Mono` at `10px`.

### Motion HUD & Video Transport
- Minimalist video scrubbers featuring high-precision timecode counters (`00:01:24 // 00:04:12`) in `JetBrains Mono`.
- The scrub track is a `2px` hairline in `#2E2B27`, filled progressively with `#FFD900`.